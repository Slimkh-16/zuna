window.onload = function() {
  // PRELOADER
  var body = document.querySelector('body');
  body.classList.remove('noscroll')
  body.classList.add('loading')
  setTimeout(function(){body.classList.add('loaded')},1800)
  setTimeout(function(){document.querySelector('.preloader').style.display = 'none';},2500)
  // //PRELOADER
}
window.onresize = function() {
  if(document.querySelector('.news-window') != undefined){
  }
}
window.onscroll = function() {
  var scrollTop = window.pageYOffset ? window.pageYOffset : (document.documentElement.scrollTop ? document.documentElement.scrollTop : document.body.scrollTop);
  if(document.querySelector('.section-nav') != undefined){
  }
}
var isMobile = false;
if (navigator.userAgent.match(/Android/i) ||
  navigator.userAgent.match(/webOS/i) ||
  navigator.userAgent.match(/iPhone/i) ||
  navigator.userAgent.match(/iPad/i) ||
  navigator.userAgent.match(/iPod/i) ||
  navigator.userAgent.match(/BlackBerry/i)) {
  isMobile = true;
};
// $(window).scroll(function() {
//   var e = $(window).scrollTop()/4,
//     a = 0,
//     b = 0;
//     elAn.style.WebkitTransform ='translate3d(' + a + 'px, ' + -e + 'px, ' + b + 'px)';
// })
$(document).ready(function() {
  if (isMobile == false && $('.animate-img').length) {
      // top animation
      $('html').mousemove(function(e){
          var wx = $(window).width();
          var wy = 250;
          var x = e.pageX - this.offsetLeft;
          var y = e.pageY - this.offsetTop;
          var newx = x - wx/2;
          var newy = y - wy/2;
          $('.animate-img').each(function(){
              var speed = $(this).attr('data-speed');
              if($(this).attr('data-revert')) speed *= -5;
              TweenMax.to($(this), 1, {x: (20 - newx*speed), y: (20+ newy*speed)});
          });
      });
      // top animation
  }
  // animate icon
  if($('.our-plus-item').length){
    var icon1 = document.querySelector('.our-plus-item--1'),
        icon1_2Elem = document.querySelector('.icon1_2Elem'),
        icon1_1Elem = document.querySelector('.icon1_1Elem');
    var tl = new TimelineMax({paused: true});
      tl.to(icon1_1Elem, 1, {rotation:360,transformOrigin:'55% 50%'});
      icon1.addEventListener("mouseenter", function(){
        tl.play();
      });
      icon1.addEventListener("mouseleave", function(){
        tl.reverse();
      });
    var icon2 = document.querySelector('.our-plus-item--2'),
        tb = new TimelineMax({paused: true }),
        icon2_1Elem = document.querySelectorAll('.icon2_1Elem');
        for (var i = 0; i < icon2_1Elem.length; i++ ) {
          var thisPause = Math.random()*1.5;
          tb.to(icon2_1Elem[i], 1, {y: -25, alpha: 0 ,repeat: -1},thisPause);
        }
      icon2.addEventListener("mouseenter", function(){
        tb.play();
      });
      icon2.addEventListener("mouseleave", function(){
        tb.stop();
      });
    var icon3 = document.querySelector('.our-plus-item--3'),
        tc = new TimelineMax({paused: true ,repeat: -1}),
        icon3_1Elem = document.querySelectorAll('.icon3_1Elem');
        tc.to(icon3_1Elem, 0.1, {rotation: 5, transformOrigin:'0% 50%'})
          .to(icon3_1Elem, 0.1, {rotation: -5, transformOrigin:'0% 50%'});
      icon3.addEventListener("mouseenter", function(){
        tc.play();
      });
      icon3.addEventListener("mouseleave", function(){
        tc.stop();
      });
    var icon4 = document.querySelector('.our-plus-item--4'),
        icon4_1Elem = document.querySelector('.icon4_1Elem');
    var te = new TimelineMax({paused: true, repeat: -1});
      te.to(icon4_1Elem, 0.5, {scale:1.2, rotation:360,transformOrigin:'50% 50%'})
        .to(icon4_1Elem, 0.5, {scale:0.8})
        .to(icon4_1Elem, 0.5, {rotation:360, scale:1,transformOrigin:'50% 50%'});
      icon4.addEventListener("mouseenter", function(){
        te.play();
      });
      icon4.addEventListener("mouseleave", function(){
        te.stop();
      });
    }
  // animate icon
  $('.section').scrollSpy()
  $('#fullpage').fullpage({
    responsiveHeight: 750,
    responsiveWidth: 1199,
    css3:true,
    easingcss3: 'cubic-bezier(0.65, 0.05, 0.36, 1)',
    slidesNavigation: true,
    // scrollOverflow: true,
    anchors: ['sectionBeg', 'sect1', 'sect2', 'sect3', 'sect4','sect5', 'sect6', 'sect7', 'sect8'],
    menu: '#menu',
    // scrollOverflowOptions: {
    //   scrollbars: true,
    //       mouseWheel: true,
    //       hideScrollbars: false,
    //       fadeScrollbars: false,
    //       disableMouse: true
    // }
    hybrid:true,
    fitToSection: false
  });

  $(document).on('click','.product-item-icon',function(){
    var dataT = $(this).parents('.product-item').attr('data-tk');
    if ($(this).parents('.product-item').hasClass('active')) {
      $(this).parents('.product-item').removeClass('active');
      $('.product-box').removeClass('active');
      setTimeout(function(){
        $('.product-box').slideUp(300);
      },500);
      setTimeout(function(){
        // $.fn.fullpage.reBuild();
      },800)
    }else {
      $('.product-item').removeClass('active');
      $(this).parents('.product-item').addClass('active');
      $('.product-box').slideUp(300);
      $('.product-box[data-tk="' + dataT + '"]').slideDown(300);
      setTimeout(function(){
        $('.product-box[data-tk="' + dataT + '"]').addClass('active');
      },500);
      setTimeout(function(){
        $('body, html').animate({scrollTop: $('#areaProduct').offset().top - $(window).height()/2},500);
        // $.fn.fullpage.reBuild();
      },800)
    }
  });
  // open product
  $(document).on('click','.product-box__item',function(){
    var prodId = $(this).attr('data-view-product');
    $('.overlay').addClass('visible');
    setTimeout(function(){$('.product-window[data-view-product='+ prodId +']').addClass('visible')},300);
    // $(document).on('scroll DOMMouseScroll wheel swipe',function(e){
    //   e.preventDefault();
    // });
    $.fn.fullpage.setAllowScrolling(false);
    return false;
  });
  $(document).on('click','.overlay',function(){
    $('.product-window').removeClass('visible')
    setTimeout(function(){
      $('.overlay').removeClass('visible');
      $.fn.fullpage.setAllowScrolling(true);
    },300);
  });
  $('.js_close_prod').on('click',function(){
    $(this).parents('.product-window').removeClass('visible');
    setTimeout(function(){$('.overlay').removeClass('visible');},300);
    $.fn.fullpage.setAllowScrolling(true);
    return false;
  });
  $(document).on('click','.js_order',function(){
    $(this).fadeOut(200);
    $(this).parents('.product-window__info').addClass('active');
    $(this).parents('.product-window__info').find('.product-form').show();
    setTimeout(function(){
     $('.product-window__info.active').find('.product-form').addClass('visible')
    },300);
    return false;
  });
  // validate form
  $('.js_validate button[type="submit"]').on("click", function(e){
    return validate($(this).parent(".js_validate"));
  }); 
  $('.product-window__info').css('height',$(window).height() - $('.product-window__pic').height() + 150);
  $(document).on('click','.hamburger--collapse',function(){
    $(this).toggleClass('is-active');
    $('.mobile-mav').toggleClass('visible');
    // if($(this).hasClass('is-active')){
    //   $(document).on('scroll DOMMouseScroll wheel swipe',function(e){
    //     e.preventDefault();
    //   });
    // }
  })
  $(document).on('click','.mobile-mav a',function(){
    setTimeout(function(){
      $('.hamburger--collapse').removeClass('is-active');
      $('.mobile-mav').removeClass('visible');
    },600)
  });
});
$(window).resize(function(){
  $('.product-window__info').css('height',$(window).height() - $('.product-window__pic').height() + 150);
})
// validate form
function validate(form){
    var error_class = "error";
    var norma_class = "pass";
    var item        = form.find("[required]");
    var e           = 0;
    var reg         = undefined;
    var pass        = form.find('.password').val();
    var pass_1      = form.find('.password_1').val();
    var email       = false;
    var password    = false;
    var phone       = false;
    function mark (object, expression) {
        if (expression) {
            object.parent('div').addClass(error_class).removeClass(norma_class).find('.error_text').show();
            e++;
        } else
            object.parent('div').addClass(norma_class).removeClass(error_class).find('.error_text').hide();
    }
    form.find("[required]").each(function(){
        switch($(this).attr("data-validate")) {
            case undefined:
                mark ($(this), $.trim($(this).val()).length === 0);
            break;
            case "email":
                email = true;
                reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
                mark ($(this), !reg.test($.trim($(this).val())));
                email = false;
            break;
            case "phone":
                phone = true;
                reg = /[0-9 -()+]{10}$/;
                mark ($(this), !reg.test($.trim($(this).val())));
                phone = false;
            break;
            case "pass":
                password = true;
                reg = /^[a-zA-Z0-9_-]{6,}$/;
                mark ($(this), !reg.test($.trim($(this).val())));
                password = false;
            break;
            case "pass1":
                mark ($(this), (pass_1 !== pass || $.trim($(this).val()).length === 0));
            break;
            default:
                reg = new RegExp($(this).attr("data-validate"), "g");
                mark ($(this), !reg.test($.trim($(this).val())));
            break
        }
    })
    $('.js_valid_radio').each(function(){
        var inp = $(this).find('input.required');
        var rezalt = 0;
        for (var i = 0; i < inp.length; i++) {
            if ($(inp[i]).is(':checked') === true) {
                rezalt = 1;
                break;
            } else {
                rezalt = 0;
            }
        }
        if (rezalt === 0) {
           $(this).addClass(error_class).removeClass(norma_class);
            e=1;
        } else {
            $(this).addClass(norma_class).removeClass(error_class);
        }
    })
    if (e == 0) {
     return true;
    }
    else {
        form.find("."+error_class+" input:first").focus();
        return false;
    }
}
// validate form 


